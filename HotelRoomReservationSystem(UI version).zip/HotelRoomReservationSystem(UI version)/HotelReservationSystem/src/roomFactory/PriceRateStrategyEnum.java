package roomFactory;

import roomFactory.RoomType;

public enum PriceRateStrategyEnum {
    STANDARD_PRICE_RATE("Standard Price Rate"),
    EVENT_TIME_PRICE_RATE("Event Time Price Rate"),
    NEW_YEAR_PRICE_RATE("New Year Price Rate");

    private final String label;

    PriceRateStrategyEnum(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static PriceRateStrategyEnum getStrategyEnum(String label) {
        PriceRateStrategyEnum[] strategies = PriceRateStrategyEnum.values();
        for (PriceRateStrategyEnum strategy : strategies) {
            if (strategy.label.equalsIgnoreCase(label)) {
                return strategy;
            }
        }
        throw new IllegalArgumentException("Invalid price rate strategy: " + label);
    }

    public static String[] getPriceRateStrategyString() {
        PriceRateStrategyEnum[] priceRateStrategy = PriceRateStrategyEnum.values();
        String[] priceRateStr = new String[priceRateStrategy.length];
        for (int i = 0; i < priceRateStrategy.length; i++) {
            priceRateStr[i] = priceRateStrategy[i].getLabel();
        }
        return priceRateStr;
    }
}
