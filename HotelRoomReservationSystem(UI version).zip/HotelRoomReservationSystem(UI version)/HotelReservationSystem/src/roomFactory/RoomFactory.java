package roomFactory;

public class RoomFactory {

    public static Room getRoom(RoomType roomType) {
        switch (roomType) {
            case SUPERIOR_KING_ROOM:
                return new SuperiorKingRoom();
            case SUPERIOR_TWINS:
                return new SuperiorTwins();
            case DELUXE_DOUBLE_ROOM:
                return new DeluxeDoubleRoom();
            case DELUXE_TWIN_ROOM:
                return new DeluxeTwinRoom();
            case PREMIER_LAKE:
                return new PremierLake();
            case PREMIER_LAKE_VIEW_TWIN_ROOM:
                return new PremierLakeViewTwinRoom();
            case CLUB_FLOOR_DELUXE_ROOM:
                return new ClubFloorDeluxeRoom();
            case CLUB_DELUXE_TWIN:
                return new ClubDeluxeTwin();
            case CLUB_PREMIER_TWIN:
                return new ClubPremierTwin();
            case CLUB_PREMIER_ROOM:
                return new ClubPremierRoom();
            case CLUB_JUNIOR_SUITE:
                return new ClubJuniorSuite();
            case JUNIOR_SUITE:
                return new JuniorSuite();
            case SUPERIOR_SUITE:
                return new SuperiorSuite();
            default:
                throw new IllegalArgumentException("Invalid room type: " + roomType);
        }
    }
}
