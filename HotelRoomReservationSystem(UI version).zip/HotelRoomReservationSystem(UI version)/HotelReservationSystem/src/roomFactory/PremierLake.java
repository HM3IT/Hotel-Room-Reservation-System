package roomFactory;

import hotelBookingSystem.FilterAttribute;

class PremierLake implements Room {

    private RoomType type = RoomType.PREMIER_LAKE;
    private String description;
    private double price;
    private String roomNum;
    private RoomStatus status;
    private Customer customer;

    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public RoomType getType() {
        return this.type;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    @Override
    public double getPrice() {
        return this.price;
    }

    @Override
    public void setRoomNum(String roomNum) {
        this.roomNum = roomNum;
    }

    @Override
    public void setStatus(RoomStatus status) {
        this.status = status;
    }

    @Override
    public String getRoomNum() {
        return this.roomNum;
    }

    @Override
    public RoomStatus getStatus() {
        return this.status;
    }

    @Override
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public Customer getCustomer() {
        return customer;
    }

    @Override
    public String getValue(FilterAttribute attr) {
        switch (attr) {
            case ROOM_NO: {
                return this.getRoomNum();
            }
            case NAME: {
                return this.getCustomer().getName();
            }
            default:
                throw new IllegalArgumentException("Invalid filter attribute type: " + attr);
        }
    }

    @Override
    public int compareTo(FilterAttribute attr, Room room) {
        return this.getValue(attr).compareTo(room.getValue(attr));
    }

    @Override
    public int compareTo(FilterAttribute attr, String keyword) {
        return this.getValue(attr).compareTo(keyword);
    }
}
