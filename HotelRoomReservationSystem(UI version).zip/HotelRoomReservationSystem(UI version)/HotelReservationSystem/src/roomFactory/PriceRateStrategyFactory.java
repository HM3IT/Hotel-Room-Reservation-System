package roomFactory;

public class PriceRateStrategyFactory {

    public static PriceRateStrategy getInstnace(PriceRateStrategyEnum priceRateStrategy) {
        switch (priceRateStrategy) {
            case STANDARD_PRICE_RATE:
                return new StandardPriceRateStrategy();
            case EVENT_TIME_PRICE_RATE:
                return new EventTimePriceRateStrategy();
            case NEW_YEAR_PRICE_RATE:
                return new NewYearPriceRateStrategy();
            default:
                throw new IllegalArgumentException("Invalid price rate strategy :" + priceRateStrategy);

        }
    }

}
