package roomFactory;

public class EventTimePriceRateStrategy implements PriceRateStrategy {

    private final double EVENT_TIME_RATE = 150.00;

    @Override
    public double calculatePrice(int duration, double roomFees) {

        return duration * roomFees * EVENT_TIME_RATE;
    }
}
