package roomFactory;

public interface PriceRateStrategy {

    public double calculatePrice(int duration, double roomFees);
}
