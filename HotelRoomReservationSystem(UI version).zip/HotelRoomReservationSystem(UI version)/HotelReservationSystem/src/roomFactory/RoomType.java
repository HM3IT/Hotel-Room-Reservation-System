package roomFactory;

public enum RoomType {
    SUPERIOR_KING_ROOM("Superior king room"),
    SUPERIOR_TWINS("Superior twins"),
    DELUXE_DOUBLE_ROOM("Deluxe double room"),
    DELUXE_TWIN_ROOM("Deluxe twin room"),
    PREMIER_LAKE("Premier lake"),
    PREMIER_LAKE_VIEW_TWIN_ROOM("Premier lake view twin room"),
    CLUB_FLOOR_DELUXE_ROOM("Club floor deluxe room"),
    CLUB_DELUXE_TWIN("Club deluxe twin"),
    CLUB_PREMIER_TWIN("Club premier twin"),
    CLUB_PREMIER_ROOM("Club premier room"),
    CLUB_JUNIOR_SUITE("Club junior suite"),
    JUNIOR_SUITE("Junior suite"),
    SUPERIOR_SUITE("Superior suite");

    private final String label;

    RoomType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static RoomType getRoomTypeEnum(String label) {
        RoomType[] roomTypes = RoomType.values();
        for (RoomType roomType : roomTypes) {
            if (roomType.label.equalsIgnoreCase(label)) {
                return roomType;
            }
        }
        throw new IllegalArgumentException("Invalid room type: " + label);
    }

    public static String[] getRoomTypeString() {
        RoomType[] roomTypes = RoomType.values();
        String[] roomTypeStr = new String[roomTypes.length];
        for (int i = 0; i < roomTypes.length; i++) {
            roomTypeStr[i] = roomTypes[i].getLabel();
        }
        return roomTypeStr;
    }
}
