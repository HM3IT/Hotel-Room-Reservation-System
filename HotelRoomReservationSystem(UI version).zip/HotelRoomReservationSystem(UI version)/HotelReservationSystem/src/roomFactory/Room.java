package roomFactory;

import hotelBookingSystem.FilterAttribute;

public interface Room {

    public void setDescription(String description);

    public void setPrice(double price);

    public double getPrice();

    public void setRoomNum(String roomNum);

    public void setStatus(RoomStatus status);

    public void setCustomer(Customer customer);

    public RoomType getType();

    public String getDescription();

    public String getRoomNum();

    public RoomStatus getStatus();

    public Customer getCustomer();

    // For search & sort features
    public String getValue(FilterAttribute attr);

    public int compareTo(FilterAttribute attr, Room room);

    public int compareTo(FilterAttribute attr, String str);

}
