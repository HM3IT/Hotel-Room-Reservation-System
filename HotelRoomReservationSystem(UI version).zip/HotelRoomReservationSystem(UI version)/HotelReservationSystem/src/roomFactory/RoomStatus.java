package roomFactory;

public enum RoomStatus {
    BOOKING("Booking"), CHECK_IN("Check-in"), AVAILABLE("Available");

    private final String label;

    RoomStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static RoomStatus getStatusEnum(String label) {
        RoomStatus[] statuses = RoomStatus.values();
        for (RoomStatus status : statuses) {

            if (status.label.equalsIgnoreCase(label)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status: " + label);
    }
}
