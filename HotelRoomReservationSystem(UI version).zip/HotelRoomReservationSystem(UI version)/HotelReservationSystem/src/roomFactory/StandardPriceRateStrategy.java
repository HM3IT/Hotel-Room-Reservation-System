package roomFactory;

public class StandardPriceRateStrategy implements PriceRateStrategy {

    private final double STANDARD_RATE = 100.00;

    @Override
    public double calculatePrice(int duration, double roomFees) {

        return duration * roomFees * STANDARD_RATE;
    }
}
