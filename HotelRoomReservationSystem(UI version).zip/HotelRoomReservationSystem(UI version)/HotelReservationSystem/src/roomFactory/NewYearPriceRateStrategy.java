package roomFactory;

public class NewYearPriceRateStrategy implements PriceRateStrategy {

    private double NEW_YEAR_RICE = 180.00;

    @Override
    public double calculatePrice(int duration, double roomFees) {
        return duration * roomFees * NEW_YEAR_RICE;
    }
}
