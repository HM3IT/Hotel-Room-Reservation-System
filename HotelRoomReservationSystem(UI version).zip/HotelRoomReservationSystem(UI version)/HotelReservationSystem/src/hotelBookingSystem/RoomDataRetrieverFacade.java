package hotelBookingSystem;

import java.util.ArrayList;
import java.util.HashMap;
import roomFactory.Room;
import roomFactory.RoomType;

public interface RoomDataRetrieverFacade {

    public HashMap<String, Room> getAllRoom();

    public ArrayList<Room> getAllBookingRoom();

    public Room getBookingRoom(String name, String phone);

    public ArrayList<Room> getAvailableRooms();

    public ArrayList<Room> getNotAvailableRoom();

    public ArrayList<Room> getCheckInAbleRooms();

    public ArrayList<Room> getCheckInRooms();

    public ArrayList<Room> getCheckOutRecord();

    /**
     * @return arrayList that contains one room for each type without including
     * room number data
     *
     */
    public ArrayList<Room> getRoomForEachType();

    public Room getRoomBasedType(RoomType basedRoomType);

}
