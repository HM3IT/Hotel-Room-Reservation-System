package hotelBookingSystem;

import roomFactory.Room;

public interface RoomRecordManagerFacade {

    public boolean saveBookingRecord(Room room);

    public boolean saveCheckInRecord(Room room, boolean isBookingCustomer);

    public boolean saveCheckOutRecord(Room room);

}
