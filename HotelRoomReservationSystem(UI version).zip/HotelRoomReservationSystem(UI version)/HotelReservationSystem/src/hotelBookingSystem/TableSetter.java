package hotelBookingSystem;

import java.util.ArrayList;
import javax.swing.JTable;
import roomFactory.Room;

public interface TableSetter {

    public void setTableReservation(JTable tblRoomType, ArrayList<Room> rooms);

    public void setTableBookingRoom(JTable tblBookingRoom, ArrayList<Room> rooms);

    public void setTableAvailableRoom(JTable tblAvaRoom, ArrayList<Room> availableRooms);

    public void setTableCheckInRoom(JTable tblBookingRoom, ArrayList<Room> rooms);

    public void setTableCheckOutRoom(JTable tblBookingRoom, ArrayList<Room> rooms);

}
