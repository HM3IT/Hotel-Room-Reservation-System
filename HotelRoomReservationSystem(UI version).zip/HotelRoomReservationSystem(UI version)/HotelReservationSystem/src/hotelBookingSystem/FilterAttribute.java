package hotelBookingSystem;

public enum FilterAttribute{
    ROOM_NO, NAME;
}
