package hotelBookingSystem;

import java.time.LocalDate;
import roomFactory.Room;
import roomFactory.RoomType;

public class RoomAvailabilityChecker {

    /**
     * Checking if there have any available room based on
     *
     * @param roomType, a room type that the customer want to booked
     * @param checkInDate, the customer's check-in date
     * @param duration, the customer's expected duration
     * @return true if there has available room. Otherwise, false
     */
    public boolean isRoomBookable(RoomType roomType, LocalDate checkInDate, int duration) {
        RoomDataRetrieverFacade roomDatRetriever = new RoomDataRetriever();

        LocalDate checkOutDate = checkInDate.plusDays(duration);

        // counting the check-in room of the specific room type based on check-in date 
        int checkInRoom = 0;
        // total room of the specific room type
        int total = 0;
        int nonRoom = 0;

        for (Room room : roomDatRetriever.getAllRoom().values()) {
            if (room.getType() == roomType) {
                total++;

                // the room is not booked, otherwise it is available
                if (room.getCustomer() == null) {
                    nonRoom++;
                    continue;
                }

                LocalDate startDate = room.getCustomer().getCheckInDate();
                LocalDate endDate = startDate.plusDays(room.getCustomer().getDuration());

                // If the check-in date overlaps with an existing check-in room, the room is not available
                if ((checkInDate.isEqual(startDate) || checkInDate.isAfter(startDate)) && checkInDate.isBefore(endDate)) {
                    checkInRoom++;
                } // If the check-out date overlaps with an existing booking, the room is not available
                else if ((checkOutDate.isEqual(endDate) || checkOutDate.isAfter(startDate)) && checkOutDate.isBefore(endDate)) {
                    checkInRoom++;
                }
            }
        }
        System.out.println("Total " + total + " || Check-in room :" + checkInRoom + " || Non" + nonRoom);
        return total - checkInRoom > 0;
    }
}
