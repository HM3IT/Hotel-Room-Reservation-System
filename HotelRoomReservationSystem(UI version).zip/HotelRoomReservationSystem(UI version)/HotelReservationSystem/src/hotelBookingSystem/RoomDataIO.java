package hotelBookingSystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import roomFactory.RoomFactory;
import roomFactory.Room;
import roomFactory.Customer;
import roomFactory.RoomStatus;
import roomFactory.RoomType;

class RoomDataIO {

    private static RoomDataIO database;
    private HashMap<String, Room> roomHm;
    private ArrayList<Room> bookingRoom;
    private final String ROOM_FILE_PATH = "Data/Room.txt";
    private final String RESERVATION_RECORD_FILE_PATH = "Data/Reservation.txt";

    private RoomDataIO() {
        roomHm = new HashMap<>();
        bookingRoom = new ArrayList<>();
        loadRoomRecord();
    }

    protected static RoomDataIO getInstance() {
        if (database == null) {
            database = new RoomDataIO();
        }
        return database;
    }

    private void loadRoomRecord() {
        // these two methods have to be called in a specific order
        readRoomFile();
        readReservationFile();
    }

    /**
     * @return the roomHm
     */
    HashMap<String, Room> getRoomHm() {
        return roomHm;
    }

    /**
     * @return the bookingRoom
     */
    ArrayList<Room> getBookingRoom() {
        return bookingRoom;
    }

    private void readRoomFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(ROOM_FILE_PATH))) {
            String str = br.readLine();
            while (str != null) {
                /**
                 * @param "#" is a special character that is used to separate
                 * the String from the text file when saving or retrieving data
                 */
                String[] values = str.split("#");
                RoomType rooomType = RoomType.getRoomTypeEnum(values[0]);
                String description = values[1];
                double cost = Double.parseDouble(values[2]);

                // Default by avaliable (Wil be updated during the file reading of reservation.txt)
                RoomStatus status = RoomStatus.AVAILABLE;
                String[] roomNums = values[3].split(",");

                for (String roomNum : roomNums) {
                    Room room = RoomFactory.getRoom(rooomType);
                    room.setRoomNum(roomNum);
                    room.setDescription(description);
                    room.setPrice(cost);
                    room.setStatus(status);
                    if (room.getStatus() == RoomStatus.CHECK_IN) {
                        System.out.println(room.getPrice());
                    }

                    getRoomHm().put(roomNum, room);
                }
                str = br.readLine();
            }

        } catch (IOException e) {
            System.err.println(ROOM_FILE_PATH + " file reader error occur");
        }
    }

    private void readReservationFile() {
        try (BufferedReader in = new BufferedReader(new FileReader(RESERVATION_RECORD_FILE_PATH))) {
            String str = in.readLine();
            while (str != null) {
                // Booking & Check-in customer data
                String[] values = str.split("#");
                LocalDate reservationDate = LocalDate.parse(values[0]);
                LocalDate arrivalDate = LocalDate.parse(values[1]);
                int duration = Integer.parseInt(values[2]);

                RoomType roomType = RoomType.getRoomTypeEnum(values[3]);
                String name = values[4];
                String phone = values[5];
                String statusStr = values[values.length - 2];
                RoomStatus status = RoomStatus.getStatusEnum(statusStr);

                Room room = getRoomBasedType(roomType);

                Customer customer = new Customer(name, phone, duration, reservationDate, arrivalDate);
                room.setCustomer(customer);
                room.setStatus(status);

                // checking {room number field} to know if the record is for reservation 
                if (values[6].equals("-")) {
                    getBookingRoom().add(room);
                    // Additional data of Check-in customers
                    // room number & total fees
                } else if (!values[6].equals("-") && values[values.length - 1].equals("-")) {
                    String roomNum = values[6];
                    room.setRoomNum(roomNum);
                    getRoomHm().put(roomNum, room);
                }

                str = in.readLine();
            }
        } catch (IOException e) {
            System.err.println(RESERVATION_RECORD_FILE_PATH + " reservation file reader error occur");
        }
    }

    Room getRoomBasedType(RoomType basedRoomType) {
        try (BufferedReader br = new BufferedReader(new FileReader(ROOM_FILE_PATH))) {
            String str = br.readLine();

            while (str != null) {
                String[] values = str.split("#");
                RoomType roomType = RoomType.getRoomTypeEnum(values[0]);
                if (roomType == basedRoomType) {
                    String description = values[1];
                    double price = Double.parseDouble(values[2]);
                    Room room = RoomFactory.getRoom(roomType);
                    room.setDescription(description);
                    room.setPrice(price);
                    return room;
                }
                str = br.readLine();
            }
        } catch (IOException e) {
            System.err.println(ROOM_FILE_PATH + " not found {file reader errors occur}");
        }
        return null;
    }

    ArrayList<Room> getRoomForEachType() {

        ArrayList<Room> roomTypeAryList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ROOM_FILE_PATH))) {
            String str = br.readLine();

            while (str != null) {
                String[] values = str.split("#");
                RoomType roomType = RoomType.getRoomTypeEnum(values[0]);
                String description = values[1];
                double price = Double.parseDouble(values[2]);
                Room room = RoomFactory.getRoom(roomType);
                room.setDescription(description);
                room.setPrice(price);
                roomTypeAryList.add(room);
                str = br.readLine();
            }
            return roomTypeAryList;
        } catch (IOException e) {
            System.err.println(ROOM_FILE_PATH + " not found {file reader errors occur}");
        }
        return null;
    }

    ArrayList<Room> getCheckOutRecord() {
        ArrayList<Room> checkOutRecord = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RESERVATION_RECORD_FILE_PATH))) {

            String str = br.readLine();
            while (str != null) {

                String[] values = str.split("#");
                // Checking does the data has total fees
                if (values[8].equals("-")) {
                    str = br.readLine();
                    continue;
                }
                LocalDate reservationDate = LocalDate.parse(values[0]);
                LocalDate arrivalDate = LocalDate.parse(values[1]);
                int duration = Integer.parseInt(values[2]);

                RoomType roomType = RoomType.getRoomTypeEnum(values[3]);
                String name = values[4];
                String phone = values[5];
                String statusStr = values[values.length - 2];
                RoomStatus status = RoomStatus.getStatusEnum(statusStr);
                Room room = RoomFactory.getRoom(roomType);
                Customer customer = new Customer(name, phone, duration, reservationDate, arrivalDate);

                room.setStatus(status);

                String roomNum = values[6];
                room.setRoomNum(roomNum);

                // Additional data of check-out customers
                LocalDate departureDate = LocalDate.parse(values[7]);
                double toatlFees = Double.parseDouble(values[8]);
                String comment = values[values.length - 1];
                customer.setDepartureDate(departureDate);
                customer.setRoomFees(toatlFees);
                customer.setComment(comment);
                room.setCustomer(customer);
                checkOutRecord.add(room);
                str = br.readLine();
            }
            return checkOutRecord;

            // Close the streams
        } catch (IOException e) {
            System.err.println(RESERVATION_RECORD_FILE_PATH + " Reservation file reader errors occur");
            return null;
        }
    }

    boolean updateRoomRecord(Room room) {
        return updateRoomRecord(room, false);
    }

    boolean updateRoomRecord(Room updatedRoom, boolean haveBooking) {
        // First time booking customers & direct check-in customers
        if ((updatedRoom.getStatus() == RoomStatus.BOOKING || updatedRoom.getStatus() == RoomStatus.CHECK_IN) && !haveBooking) {

            ArrayList<String> newRecord = new ArrayList<>(1);
            Customer newCustomer = updatedRoom.getCustomer();
            String roomNum = updatedRoom.getRoomNum();
            if (roomNum == null || roomNum.isEmpty()) {
                roomNum = "-";
            }
            String newData = String.valueOf(newCustomer.getReservationDate()) + "#" + newCustomer.getCheckInDate() + "#" + newCustomer.getDuration() + "#" + updatedRoom.getType().getLabel() + "#" + newCustomer.getName() + "#" + newCustomer.getPhNum() + "#" + roomNum + "#-#-#" + updatedRoom.getStatus().getLabel() + "#-";
            newRecord.add(newData);
            return writeRoomRecord(newRecord, true);
        }

        ArrayList<String> roomRecords = new ArrayList<>();

        RoomStatus newStatus = updatedRoom.getStatus();
        Customer newCustomer = updatedRoom.getCustomer();
        String newName = newCustomer.getName();
        String newRoomNum = updatedRoom.getRoomNum();
        LocalDate newReservation = newCustomer.getReservationDate();

        try (BufferedReader br = new BufferedReader(new FileReader(RESERVATION_RECORD_FILE_PATH))) {
            String str = br.readLine();

            while (str != null) {
                // Booking & Check-in customer data
                String[] values = str.split("#");
                LocalDate reservationDate = LocalDate.parse(values[0]);
                LocalDate checkInDate = LocalDate.parse(values[1]);
                int duration = Integer.parseInt(values[2]);

                String name = values[4];
                String phone = values[5];

                String roomTypeStr = values[3];

                String statusStr = values[values.length - 2];
                RoomStatus status = RoomStatus.getStatusEnum(statusStr);

                String roomNum = values[6];
                String checkOutDate = values[7];
                String totalFees = values[8];
                String comment = values[10];

                if (reservationDate.equals(newReservation) && newName.equals(name)) {

                    switch (newStatus) {
                        // Modifying the booking room data  to  check-in
                        case CHECK_IN:
                            if (!"-".equals(newRoomNum) && "-".equals(roomNum)
                                    && status == RoomStatus.BOOKING) {
                                System.out.println("UPPER ");
                                // Modified data-> status & roomNum & roomType (customer might change during booking if available)
                                roomTypeStr = updatedRoom.getType().getLabel();
                                roomNum = newRoomNum;
                                statusStr = newStatus.getLabel();
                            }
                            break;
                        // Modifying the check-in data to check-out
                        case AVAILABLE:

                            if (newRoomNum.equals(roomNum)
                                    && status == RoomStatus.CHECK_IN) {
                                System.out.println("LOWER");
                                // check-out -> status & totalFees & comment
                                statusStr = newStatus.getLabel();
                                totalFees = newCustomer.getRoomFees() + "";
                                comment = newCustomer.getComment();
                                checkOutDate = newCustomer.getDepartureDate().toString();
                            }
                            break;

                        default:
                            break;
                    }
                }

                String record = reservationDate + "#" + checkInDate + "#" + duration + "#" + roomTypeStr + "#" + name + "#" + phone
                        + "#" + roomNum + "#" + checkOutDate + "#" + totalFees + "#" + statusStr + "#" + comment;
                roomRecords.add(record);
                str = br.readLine();
            }

            writeRoomRecord(roomRecords, false);
            return true;

        } catch (IOException e) {
            System.err.println(ROOM_FILE_PATH + " not found {file reader errors occur}");
        }

        return false;
    }

    private boolean writeRoomRecord(ArrayList<String> roomDataStr, boolean append) {

        try (PrintWriter pw = new PrintWriter(new FileWriter(RESERVATION_RECORD_FILE_PATH, append))) {
            // Writing room data with the status: Booking and Check in     
            for (String data : roomDataStr) {
                pw.println(data);
            }
            return true;
        } catch (IOException e) {
            System.err.println(RESERVATION_RECORD_FILE_PATH + " save Reservation error occurs");
        }
        return false;
    }
}
