package hotelBookingSystem;

import java.util.ArrayList;
import roomFactory.Room;

public interface RoomSearchSortFacade {

    int getIndexOfCustomer(String name, String phone, ArrayList<Room> resource);

    Room getRoom(FilterAttribute baseAttr, String keyword, ArrayList<Room> resource);

    ArrayList<Room> getRoomBasedType(String roomType, ArrayList<Room> rooms);

    ArrayList<Room> getRoomsBasedName(ArrayList<Room> resource, String keyword,
            boolean caseSensitive);

    void sortRooms(FilterAttribute baseAttr, ArrayList<Room> rooms);
}
