package hotelBookingSystem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;
import roomFactory.Room;
import roomFactory.RoomStatus;
import roomFactory.RoomType;

public class RoomDataRetriever implements RoomDataRetrieverFacade {

    private RoomDataIO roomDataIO;
    private RoomSearchSortFacade roomSearchSort;

   RoomDataRetriever() {
        roomDataIO = RoomDataIO.getInstance();
        roomSearchSort = new RoomSearchSort();
    }

    @Override
    public HashMap<String, Room> getAllRoom() {
        return roomDataIO.getRoomHm();
    }

    @Override
    public ArrayList<Room> getAllBookingRoom() {
        return roomDataIO.getBookingRoom();
    }

    @Override
    public ArrayList<Room> getAvailableRooms() {
        return (ArrayList<Room>) roomDataIO.getRoomHm().values().stream()
                .filter(room -> room.getStatus() == RoomStatus.AVAILABLE)
                .collect(Collectors.toList());
    }

    @Override
    public ArrayList<Room> getNotAvailableRoom() {
        return (ArrayList<Room>) roomDataIO.getRoomHm().values().stream()
                .filter(room -> room.getStatus() != RoomStatus.AVAILABLE)
                .collect(Collectors.toList());
    }

    @Override
    public ArrayList<Room> getCheckInAbleRooms() {

        return (ArrayList<Room>) roomDataIO.getRoomHm().values().stream()
                .filter(room -> room.getStatus() == RoomStatus.AVAILABLE)
                .collect(Collectors.toList());
    }

    @Override
    public ArrayList<Room> getCheckInRooms() {
        return (ArrayList<Room>) roomDataIO.getRoomHm().values().stream()
                .filter(room -> room.getStatus() == RoomStatus.CHECK_IN)
                .collect(Collectors.toList());
    }

    @Override
    public ArrayList<Room> getCheckOutRecord() {
        return roomDataIO.getCheckOutRecord();
    }

    /**
     * @return arrayList that contains one room for each type without including
     * room number data
     *
     */
    @Override
    public ArrayList<Room> getRoomForEachType() {
        return roomDataIO.getRoomForEachType();
    }

    @Override
    public Room getBookingRoom(String name, String phone) {

        int index = roomSearchSort.getIndexOfCustomer(name, phone, roomDataIO.getBookingRoom());

        return roomDataIO.getBookingRoom().get(index);
    }

    @Override
    public Room getRoomBasedType(RoomType basedRoomType) {
        return roomDataIO.getRoomBasedType(basedRoomType);
    }

}
