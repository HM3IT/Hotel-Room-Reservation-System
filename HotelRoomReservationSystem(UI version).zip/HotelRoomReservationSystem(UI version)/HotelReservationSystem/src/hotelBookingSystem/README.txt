Hotel Room Reservation System

         The Hotel Room Reservation System is a program that helps hotels manage their room reservations. This system requires the jcalendar-1.4 plugin file to be installed in order to work properly.

Installation
     To run the Hotel Room Reservation System properly, please follow these steps:

1. Download the jcalendar-1.4 plugin file.
2. Add the jcalendar-1.4 plugin file to the project's classpath.
3. Run the program by starting the AdminLogin.java file.

Usage
      The Hotel Room Reservation System allows hotel administrators to manage room reservations, including creating new reservations, modifying existing ones, and saving reservations. To use the system, simply log in as an administrator using the AdminLogin.java file.

