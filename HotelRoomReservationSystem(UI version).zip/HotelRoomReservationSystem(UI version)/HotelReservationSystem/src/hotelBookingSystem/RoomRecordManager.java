package hotelBookingSystem;

import roomFactory.Customer;
import roomFactory.Room;
import roomFactory.RoomStatus;

public class RoomRecordManager implements RoomRecordManagerFacade {

    private RoomDataRetrieverFacade roomDataRetrieverFacade;
    private RoomSearchSortFacade roomSearchSort;
    private RoomDataIO roomDataIO;

    RoomRecordManager() {
        roomDataIO = RoomDataIO.getInstance();
        roomDataRetrieverFacade = new RoomDataRetriever();
        roomSearchSort = new RoomSearchSort();
    }

    @Override
    public boolean saveBookingRecord(Room room) {
        if (roomDataIO.updateRoomRecord(room)) {
            //Updating the booking room cache 
            addBookingRoom(room);
            return true;
        }
        return false;
    }

    @Override
    public boolean saveCheckInRecord(Room room, boolean haveBooking) {

        if (roomDataIO.updateRoomRecord(room, haveBooking)) {
            //Updating the booking rooom cache 
            updateRoomStatus(room.getRoomNum(), room.getStatus());
            setCustomerToRoom(room.getRoomNum(), room.getCustomer());

            // removing the customer from booking cache
            if (haveBooking) {
                removeBookingRoom(room);
            }

            return true;
        }
        return false;
    }

    @Override
    public boolean saveCheckOutRecord(Room room) {
        if (roomDataIO.updateRoomRecord(room)) {
            updateRoomStatus(room.getRoomNum(), room.getStatus());
            removeCustomerFromRoom(room.getRoomNum());
            return true;
        }
        return false;
    }

    /**
     * @param roomNum the room that is about to be updated with the passed
     * RoomStatus
     * @param newStatus a new status of the room
     */
    private void updateRoomStatus(String roomNum, RoomStatus newStatus) {
        // update the room status
        roomDataRetrieverFacade.getAllRoom().get(roomNum).setStatus(newStatus);

    }

    /**
     * @param roomNum the identifier of the room to update
     * @param customer the customer to assign to the room
     */
    private void setCustomerToRoom(String roomNum, Customer customer) {
        roomDataRetrieverFacade.getAllRoom().get(roomNum).setCustomer(customer);
    }

    private void addBookingRoom(Room bookedRoom) {
        roomDataRetrieverFacade.getAllBookingRoom().add(bookedRoom);
    }

    private void removeBookingRoom(Room room) {
        Customer customer = room.getCustomer();
        int index = roomSearchSort.getIndexOfCustomer(customer.getName(), customer.getPhNum(), roomDataRetrieverFacade.getAllBookingRoom());
        if (index >= 0) {
            roomDataRetrieverFacade.getAllBookingRoom().remove(index);
        }
    }

    private void removeCustomerFromRoom(String roomNum) {
        roomDataRetrieverFacade.getAllRoom().get(roomNum).setCustomer(null);
    }

}
