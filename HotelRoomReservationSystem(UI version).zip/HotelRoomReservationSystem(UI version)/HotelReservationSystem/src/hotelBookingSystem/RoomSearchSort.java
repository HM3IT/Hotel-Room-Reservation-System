package hotelBookingSystem;

import java.util.ArrayList;
import roomFactory.Room;
import roomFactory.RoomType;

public class RoomSearchSort implements RoomSearchSortFacade {

    private RoomDataProcessor roomDataProcessor;

    RoomSearchSort() {
        roomDataProcessor = new RoomDataProcessor();
    }

    @Override
    public int getIndexOfCustomer(String name, String phone, ArrayList<Room> resource) {
        return roomDataProcessor.searchIndexOfCustomer(name, phone, resource);
    }

    @Override
    public Room getRoom(FilterAttribute baseAttr, String keyword, ArrayList<Room> resource) {
        RoomDataRetrieverFacade roomDataRetriever = new RoomDataRetriever();
        // the Hash Map data stores the room number as a key value
        if (baseAttr == FilterAttribute.ROOM_NO) {
            return roomDataRetriever.getAllRoom().get(keyword);
        }
        return roomDataProcessor.binarySearch(resource, baseAttr, keyword);
    }

    @Override
    public ArrayList<Room> getRoomBasedType(String roomType, ArrayList<Room> rooms) {

        return roomDataProcessor.linearSearch(RoomType.getRoomTypeEnum(roomType), rooms);
    }

    @Override
    public ArrayList<Room> getRoomsBasedName(ArrayList<Room> resource, String keyword,
            boolean caseSensitive) {
        return roomDataProcessor.searchString(resource, FilterAttribute.NAME, keyword, caseSensitive);
    }

    @Override
    public void sortRooms(FilterAttribute baseAttr, ArrayList<Room> rooms) {
        roomDataProcessor.quicksort(rooms, baseAttr);
    }
}
