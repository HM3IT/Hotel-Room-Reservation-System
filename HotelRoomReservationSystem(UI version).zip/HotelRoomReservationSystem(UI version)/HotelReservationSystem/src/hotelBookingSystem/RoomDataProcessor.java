package hotelBookingSystem;

import java.util.ArrayList;
import java.util.regex.Pattern;
import roomFactory.Customer;
import roomFactory.Room;
import roomFactory.RoomType;

public class RoomDataProcessor {

    public ArrayList<Room> linearSearch(RoomType baseType, ArrayList<Room> resource) {
        ArrayList<Room> matchRooms = new ArrayList<>();
        for (Room room : resource) {
            if (room.getType() == baseType) {
                matchRooms.add(room);
            }
        }
        return matchRooms;
    }

    public int searchIndexOfCustomer(String name, String phone, ArrayList<Room> resource) {
        int length = resource.size();
        for (int i = 0; i < length; i++) {
            Customer customer = resource.get(i).getCustomer();
            if (customer.getName().equals(name)
                    && customer.getPhNum().equals(phone)) {
                return i;
            }
        }
        return -1;
    }

    public Room binarySearch(ArrayList<Room> rooms, FilterAttribute baseAttr, String keyword) {
        System.out.println("Reach");

        int size = rooms.size();
        if (keyword == null || size <= 0) {
            return null;
        }
        int leftIndex = 0;
        int rightIndex = size - 1;

        while (leftIndex <= rightIndex) {
            int midIndex = leftIndex + (rightIndex - leftIndex) / 2;

            int status = rooms.get(midIndex).compareTo(baseAttr, keyword);

            if (status == 0) {
                return rooms.get(midIndex);
            } else if (status > 0) {

                rightIndex = midIndex - 1;

            } else {
                leftIndex = midIndex + 1;
            }
        }
        return null;
    }

    /**
     * @return rooms that contains all the room that matched with the given
     * @param keyword Otherwise, null
     */
    public ArrayList<Room> searchString(ArrayList<Room> rooms, FilterAttribute baseAttr, String keyword,
            boolean caseSensitive) {
        if (!caseSensitive) {
            keyword = keyword.toLowerCase().replaceAll(" ", "");
        }
        ArrayList<Room> matchRooms = new ArrayList<>();
        // Java regular expression
        String regex = ".*" + keyword + ".*";
        Pattern similarWord = Pattern.compile(regex);

        int length = rooms.size();
        for (int i = 0; i < length; i++) {
            String text = rooms.get(i).getValue(baseAttr);
            if (!caseSensitive) {
                text = text.toLowerCase();
            }
            // Using regular expression to check the bookValue is matched or not
            if (similarWord.matcher(text).matches()) {
                matchRooms.add(rooms.get(i));
            }
        }
        return !matchRooms.isEmpty() ? matchRooms : null;
    }

    // Sorting algorithms
    public void quicksort(ArrayList<Room> rooms, FilterAttribute baseAttr) {
        if (rooms.size() < 2) {
            return;
        }
        quicksort(rooms, baseAttr, 0, rooms.size() - 1);
    }

    private void quicksort(ArrayList<Room> rooms, FilterAttribute baseAttr, int leftIndex, int rightIndex) {
        if (leftIndex >= rightIndex) {
            return;
        }

        int pivotIndex = leftIndex + (rightIndex - leftIndex) / 2;
        Room pivotElement = rooms.get(pivotIndex);

        swap(rooms, pivotIndex, rightIndex);

        int mid = partation(rooms, baseAttr, leftIndex, rightIndex, pivotElement);
        quicksort(rooms, baseAttr, leftIndex, mid - 1);
        quicksort(rooms, baseAttr, mid + 1, rightIndex);
    }

    private int partation(ArrayList<Room> rooms, FilterAttribute baseAttr, int leftIndex, int rightIndex,
            Room pivotElement) {
        int leftPointer = leftIndex;
        int rightPointer = rightIndex;

        while (leftPointer < rightPointer) {
            while (leftPointer < rightPointer && rooms.get(leftPointer).compareTo(baseAttr, pivotElement) <= 0) {
                leftPointer++;
            }
            while (leftPointer < rightPointer && rooms.get(rightPointer).compareTo(baseAttr, pivotElement) >= 0) {
                rightPointer--;
            }

            swap(rooms, leftPointer, rightPointer);
        }
        swap(rooms, leftPointer, rightIndex);
        return leftPointer;
    }

    private void swap(ArrayList<Room> aryList, int index1, int index2) {
        // TODO Auto-generated method stub
        Room temp = aryList.get(index1);
        aryList.set(index1, aryList.get(index2));
        aryList.set(index2, temp);

    }

}
