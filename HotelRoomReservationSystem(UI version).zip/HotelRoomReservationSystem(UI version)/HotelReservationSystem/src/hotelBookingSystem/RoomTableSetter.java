package hotelBookingSystem;

import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import roomFactory.Customer;
import roomFactory.Room;

public class RoomTableSetter implements TableSetter {

    DefaultTableCellRenderer rightRenderer;
    DefaultTableCellRenderer leftRenderer;
    DefaultTableCellRenderer centerRenderer;

    RoomTableSetter() {
        rightRenderer = new DefaultTableCellRenderer();
        leftRenderer = new DefaultTableCellRenderer();
        centerRenderer = new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        leftRenderer.setHorizontalAlignment(JLabel.LEFT);
    }

    @Override
    public void setTableReservation(JTable tblRoomType, ArrayList<Room> rooms) {
        DefaultTableModel tblModel = (DefaultTableModel) tblRoomType.getModel();
        tblModel.setRowCount(0);
        setTblWidthReservation(tblRoomType);
        int serialNum = 1;
        for (Room room : rooms) {

            String roomType = room.getType().getLabel();

            double price = room.getPrice();
            String[] descriptions = room.getDescription().split(",");
            String description = "";
            for (int i = 0; i < descriptions.length; i++) {
                // not showing room size (Customer do not need to know)
                if (i != 1) {
                    description += descriptions[i] + ",  ";
                }
            }

            Object[] rowData = new Object[]{serialNum, roomType, price, description};
            tblModel.addRow(rowData);
            serialNum++;
        }
        // Force the table to redraw with the new data
        tblRoomType.repaint();
    }

    @Override
    public void setTableBookingRoom(JTable tblBookingRoom, ArrayList<Room> rooms) {
        DefaultTableModel tblModel = (DefaultTableModel) tblBookingRoom.getModel();

        tblModel.setRowCount(0);
//        setAvailableRoomTblWidth(tblAvaRoom);
        int serialNum = 1;
        for (Room bookingRoom : rooms) {

            Customer customer = bookingRoom.getCustomer();
            Object[] rowData = new Object[]{
                serialNum++, customer.getName(), customer.getPhNum(), bookingRoom.getType(), customer.getReservationDate(), customer.getCheckInDate(), customer.getDuration()
            };
            tblModel.addRow(rowData);
            serialNum++;

        }
        // Force the table to redraw with the new data
        tblBookingRoom.repaint();
    }

    @Override
    public void setTableAvailableRoom(JTable tblAvaRoom, ArrayList<Room> availableRooms) {

        DefaultTableModel tblModel = (DefaultTableModel) tblAvaRoom.getModel();

        tblModel.setRowCount(0);
        setAvailableRoomTblWidth(tblAvaRoom);
        int serialNum = 1;
        for (Room room : availableRooms) {
            // Chanaging status format to a more appropirate format
            String status = room.getStatus().getLabel();
            Object[] rowData = new Object[]{
                serialNum++, room.getRoomNum(), room.getType().getLabel(), room.getPrice(), status
            };
            tblModel.addRow(rowData);
            serialNum++;
        }
        // Force the table to redraw with the new data
        tblAvaRoom.repaint();
    }

    @Override
    public void setTableCheckInRoom(JTable tblCheckInRoom, ArrayList<Room> rooms) {

        DefaultTableModel tblModel = (DefaultTableModel) tblCheckInRoom.getModel();
        tblModel.setRowCount(0);
        setTblWidthCheckIn(tblCheckInRoom);
        int serialNum = 1;
        for (Room room : rooms) {
            Customer customer = room.getCustomer();
            String roomNum = room.getRoomNum();
            String roomType = room.getType().getLabel();
            double price = room.getPrice();
            String customerName = customer.getName();
            String phNum = customer.getPhNum();
            LocalDate reservationDate = customer.getReservationDate();
            LocalDate checkInDate = customer.getCheckInDate();

            Object[] rowData = new Object[]{serialNum, roomNum, roomType, price, customerName, phNum, reservationDate, checkInDate};
            tblModel.addRow(rowData);
            serialNum++;
        }
        // Force the table to redraw with the new data

        tblCheckInRoom.repaint();

    }

    @Override
    public void setTableCheckOutRoom(JTable tblCheckOut, ArrayList<Room> rooms) {

        DefaultTableModel tblModel = (DefaultTableModel) tblCheckOut.getModel();
        setTblWidthCheckOut(tblCheckOut);
        tblModel.setRowCount(0);
        int serialNum = 1;
        for (Room room : rooms) {
            Customer customer = room.getCustomer();
            String roomNum = room.getRoomNum();
            String roomType = room.getType().getLabel();

            String customerName = customer.getName();
            String phNum = customer.getPhNum();
            LocalDate reservationDate = customer.getReservationDate();
            LocalDate checkInDate = customer.getCheckInDate();
            LocalDate departDate = customer.getDepartureDate();
            int duration = customer.getDuration();
            double totalFees = customer.getRoomFees();
            String comment = customer.getComment();

            Object[] rowData = new Object[]{serialNum, roomNum, roomType, customerName, phNum, reservationDate, checkInDate, departDate, duration, totalFees, comment};
            tblModel.addRow(rowData);
            serialNum++;
        }
        // Force the table to redraw with the new data
        tblCheckOut.repaint();
    }

    private void setTblWidthReservation(JTable tblRoomType) {
        tblRoomType.getColumnModel().getColumn(0).setPreferredWidth(2);
        tblRoomType.getColumnModel().getColumn(1).setPreferredWidth(70);
        tblRoomType.getColumnModel().getColumn(2).setPreferredWidth(5);
        tblRoomType.getColumnModel().getColumn(3).setPreferredWidth(450);

        tblRoomType.getColumnModel().getColumn(1).setCellRenderer(rightRenderer);
        tblRoomType.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
        tblRoomType.getColumnModel().getColumn(3).setCellRenderer(leftRenderer);
    }

    private void setTblWidthCheckIn(JTable tblCheckIn) {
        //  Customizing the width of each column of the table manually
        tblCheckIn.setRowHeight(20);

        tblCheckIn.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblCheckIn.getColumnModel().getColumn(1).setCellRenderer(leftRenderer);
        tblCheckIn.getColumnModel().getColumn(6).setCellRenderer(leftRenderer);
        tblCheckIn.getColumnModel().getColumn(7).setCellRenderer(centerRenderer);
    }

    private void setTblWidthCheckOut(JTable tblOccupyRoom) {
        //  Customizing the width of each column of the table manually
        tblOccupyRoom.getColumnModel().getColumn(0).setPreferredWidth(5);
        tblOccupyRoom.getColumnModel().getColumn(1).setPreferredWidth(20);
        tblOccupyRoom.getColumnModel().getColumn(2).setPreferredWidth(20);
        tblOccupyRoom.getColumnModel().getColumn(3).setPreferredWidth(50);
        tblOccupyRoom.getColumnModel().getColumn(4).setPreferredWidth(70);
        tblOccupyRoom.getColumnModel().getColumn(5).setPreferredWidth(50);
        tblOccupyRoom.getColumnModel().getColumn(6).setPreferredWidth(20);
        tblOccupyRoom.getColumnModel().getColumn(7).setPreferredWidth(40);
        tblOccupyRoom.getColumnModel().getColumn(8).setPreferredWidth(40);
        tblOccupyRoom.setRowHeight(20);

        tblOccupyRoom.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblOccupyRoom.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
        tblOccupyRoom.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);
        tblOccupyRoom.getColumnModel().getColumn(7).setCellRenderer(centerRenderer);
        tblOccupyRoom.getColumnModel().getColumn(8).setCellRenderer(centerRenderer);
    }

    private void setAvailableRoomTblWidth(JTable tblAvaRoom) {
        //  Customizing the width of each column of the table manually
        tblAvaRoom.getColumnModel().getColumn(0).setPreferredWidth(5);
        tblAvaRoom.getColumnModel().getColumn(1).setPreferredWidth(15);
        tblAvaRoom.getColumnModel().getColumn(2).setPreferredWidth(50);
        tblAvaRoom.getColumnModel().getColumn(3).setPreferredWidth(15);
        tblAvaRoom.getColumnModel().getColumn(4).setPreferredWidth(15);

        tblAvaRoom.setRowHeight(20);

        tblAvaRoom.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblAvaRoom.getColumnModel().getColumn(2).setCellRenderer(leftRenderer);
        tblAvaRoom.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
    }
}
