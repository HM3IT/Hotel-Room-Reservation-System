package hotelBookingSystem;

import java.util.regex.Pattern;

public class InputValidator {

    protected boolean isValidRoomNum(String roomNum) {
        /* 
          Room.txt file, a file given by the assignment contains only the room numbers starting with 4 digit to 5 digit at most
         */
        Pattern roomNumberPattern = Pattern.compile("\\d{4,5}");
        return roomNumberPattern.matcher(roomNum).matches();
    }

    protected boolean isValidPhoneNumber(String phoneNum) {
        /*
	 * For Myanmar (Local), valid formats for phone numbers: 09-1234567 09-12345678
	 * 09-123456789 09-1234567890
         */
        phoneNum = phoneNum.replaceAll("\\s", "");
        Pattern phonePattern = Pattern.compile("^09-?\\d{7,9}$");
        return phonePattern.matcher(phoneNum).matches();
    }

    protected boolean isValidName(String name) {
        Pattern namePattern = Pattern.compile("^[a-zA-Z\\s]+$");

        return namePattern.matcher(name).matches();
    }

}
