package Complexity;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import hotelRoomReservationSystem.RoomStatus;
import hotelRoomReservationSystem.RoomType;

public class ADTComplexity {

	public static void main(String[] args) {
		String sourcePath = "src/Data/Room.txt";
		ADTComplexity spaceComplexity = new ADTComplexity();
		spaceComplexity.calcuateMaxSize(sourcePath);
		spaceComplexity.clcuateMaxLenghtOfEnum();
	}

	private void calcuateMaxSize(String filePath) {

		int countMaxRoomObj = 0, maxRoomNum = 0, maxDescription = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String str = br.readLine();

			while (str != null) {
				String[] values = str.split("#");

				String description = values[1];
				String[] roomNums = values[3].split(",");

				// identifying the max String length of description
				if (maxDescription < description.length()) {
					maxDescription = description.length();
				}
				for (String roomNum : roomNums) {
					if (maxRoomNum < roomNum.length()) {
						maxRoomNum = roomNum.length();
					}
					countMaxRoomObj++;
				}

				str = br.readLine();
			}

			System.out.println("Max number of room objects :" + countMaxRoomObj);
			System.out.println("Max number of String roomNum :" + maxRoomNum);
			System.out.println("Max length of String description :" + maxDescription);
		} catch (IOException e) {
			System.err.println(filePath + " not found {file reader errors occur}");
		}
	}

	private void clcuateMaxLenghtOfEnum() {
		int numOfRoomType = RoomType.values().length;
		int numOfStatus = RoomStatus.values().length;

		System.out.println("Room type :" + numOfRoomType);
		System.out.println("   status :" + numOfStatus);
	}
}
