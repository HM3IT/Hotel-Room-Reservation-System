package Complexity;

import java.util.LinkedList;

public class TradeOff_GC {
	public static void main(String[] args) {

		// For determine the tradeoff between the use of System.gc() method
		int initialSize = 2_000000;
		int removeSize = 21000;
		System.out.println("\nUsing System.gc() method");
		runWithGC(initialSize, removeSize);

		System.out.println("\nWithoug using System.gc() method");
		runWithoutGC(initialSize, removeSize);

	}

	private static void runWithGC(int initialSize, int removeSize) {
		long startRunTime = System.currentTimeMillis();
		LinkedList<Integer> list = new LinkedList<>();

		for (int i = 0; i < initialSize; i++) {
			list.add(i);
		}

		// measure memory usage before forcing garbage collection
		Runtime runtime = Runtime.getRuntime();
		runtime.gc();
		long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
		System.out.println("\nMemory used before removing elements from the LinkedList using GC: " + usedMemoryBefore
				+ " bytes or " + bytesToMegabytes(usedMemoryBefore) + " Megabytes");

		// remove 10,000 elements from the list
		for (int i = 0; i < removeSize; i++) {
			list.removeFirst();
		}

		// trigger garbage collection to free up memory space
		System.gc();

		long endRunTime = System.currentTimeMillis();
		long runningTime = endRunTime - startRunTime;
		System.out.println("Algorithm runtime :" + runningTime + " ms");

		// measure memory usage after forcing garbage collection
		runtime.gc();
		long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
		System.out.println("Memory used after removing elements from the LinkedList using GC:" + usedMemoryAfter
				+ " bytes or " + bytesToMegabytes(usedMemoryAfter) + " Megabytes");
	}

	private static void runWithoutGC(int initialSize, int removeSize) {
		long startRunTime = System.currentTimeMillis();
		LinkedList<Integer> list = new LinkedList<>();
		// add elements to the list
		for (int i = 0; i < initialSize; i++) {
			list.add(i);
		}

		// measure memory usage before forcing garbage collection
		Runtime runtime = Runtime.getRuntime();
		runtime.gc();
		long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
		System.out.println("\nMemory used before removing elements from the LinkedList without GC: " + usedMemoryBefore
				+ " bytes or " + bytesToMegabytes(usedMemoryBefore) + " Megabytes");

		// remove 10,000 elements from the list
		for (int i = 0; i < removeSize; i++) {
			list.removeFirst();
		}

		long endRunTime = System.currentTimeMillis();
		long runningTime = endRunTime - startRunTime;
		System.out.println("Algorithm runtime :" + runningTime + " ms");

		// measure memory usage after forcing garbage collection
		runtime.gc();
		long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
		System.out.println("Memory used after removing elements from the LinkedList without GC:" + usedMemoryAfter
				+ " bytes or " + bytesToMegabytes(usedMemoryAfter) + " Megabytes");
	}

	private static double bytesToMegabytes(long bytes) {
		return Math.round((double) bytes / (1024 * 1024));
	}
}
