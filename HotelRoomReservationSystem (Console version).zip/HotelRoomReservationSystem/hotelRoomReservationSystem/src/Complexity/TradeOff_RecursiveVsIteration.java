package Complexity;

public class TradeOff_RecursiveVsIteration {
	public static void main(String[] args) {
		System.out.println("Iteration approach");
		int size = 10;
		long startTime = System.nanoTime();
		int factorial = factorialIteration(size);
		long endTime = System.nanoTime();
		long runTime = endTime - startTime;
		// Each integer takes up 4 bytes including the factorial variable
		long spaceComplexity = (size * 4) + 4;

		System.out.println("Processing time: " + runTime + " ns");
		System.out.println("Factorial: " + factorial);
		System.out.println("Space complexity: " + spaceComplexity + " bytes");

		System.out.println("\nRecursive approach");
		startTime = System.nanoTime();
		factorial = factorialRecursion(size);
		endTime = System.nanoTime();
		runTime = endTime - startTime;
		// Each stack frame takes up 8 bytes
		spaceComplexity = size * 8;

		System.out.println("Processing time: " + runTime + " ns");
		System.out.println("Factorial: " + factorial);
		System.out.println("Space complexity: " + spaceComplexity + " bytes");

	}

	private static int factorialRecursion(int n) {
		if (n == 0 || n == 1) {
			return 1;
		}
		return n * factorialRecursion(n - 1);
	}

	private static int factorialIteration(int n) {
		int factorial = 1;
		for (int i = 1; i <= n; i++) {
			factorial *= i;
		}
		return factorial;
	}
}
