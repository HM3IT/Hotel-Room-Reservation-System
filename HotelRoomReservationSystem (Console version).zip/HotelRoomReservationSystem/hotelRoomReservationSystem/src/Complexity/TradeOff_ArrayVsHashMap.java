package Complexity;

import java.util.HashMap;

public class TradeOff_ArrayVsHashMap {
	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5 };

		System.out.println("Array approach:");
		long startTime = System.nanoTime();
		printArray(arr);
		long endTime = System.nanoTime();
		long runTime = endTime - startTime;
		System.out.println("Processing time: " + runTime + " ns");
		System.out.println("Space complexity: O(n)");

		System.out.println("\nHashMap approach:");
		startTime = System.nanoTime();
		printHashMap(arr);
		endTime = System.nanoTime();
		runTime = endTime - startTime;
		System.out.println("Processing time: " + runTime + " ns");
		System.out.println("Space complexity: O(n)");
	}

	public static void printArray(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

	public static void printHashMap(int[] arr) {
		HashMap<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < arr.length; i++) {
			map.put(i, arr[i]);
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.println(map.get(i));
		}
	}

}
