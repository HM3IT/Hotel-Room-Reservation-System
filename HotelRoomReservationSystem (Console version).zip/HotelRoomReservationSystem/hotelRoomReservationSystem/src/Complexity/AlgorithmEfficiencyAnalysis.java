package Complexity;

public class AlgorithmEfficiencyAnalysis {

	public static void main(String[] args) {
		int size = 2_000_000_00;
		int[] arr = new int[size];
		for (int i = 0; i < size; i++) {
			arr[i] = i + 1;
		}
		long startMemory, endMemory;
		Runtime runtime = Runtime.getRuntime();
		runtime.gc();
		startMemory = runtime.totalMemory() - runtime.freeMemory();

		// target value for average case
		int target = 2_000_000_01;

		// Time complexity analysis
		long startTime = System.currentTimeMillis();

		int index = linearSearch(arr, target);
//		int index = linearSearch(arr, target);

		System.out.println("Found at " + index);

		long endTime = System.currentTimeMillis();
		long runningTime = endTime - startTime;
		System.out.println("Running time: " + runningTime + " ms");

		// Space complexity analysis
		runtime.gc();
		endMemory = runtime.totalMemory() - runtime.freeMemory();
		long allocatedMemory = endMemory - startMemory + (4 * size);
		System.out.println(
				"Allocated memory: " + allocatedMemory + " bytes or " + bytesToMegabytes(allocatedMemory) + " MB");
	}

	private static double bytesToMegabytes(long bytes) {
		return (double) bytes / (1024 * 1024);
	}

	public static int binarySearch(int[] arr, int searchedValue) {
		int left = 0;
		int right = arr.length - 1;
		while (left <= right) {
			int mid = left + (right - left) / 2;
			if (arr[mid] == searchedValue) {
				return mid;
			} else if (arr[mid] < searchedValue) {
				left = mid + 1;
			} else {
				right = mid - 1;
			}
		}
		return -1;
	}

	public static int linearSearch(int[] arr, int searchedValue) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == searchedValue) {
				return i;
			}
		}
		// searchedValue not found
		return -1;
	}

}
