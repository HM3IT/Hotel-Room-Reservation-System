package hotelRoomReservationSystem;

public interface Room{

	public void setRoomNum(String roomNum);

	public void setRoomType(RoomType roomType);

	public void setDescription(String description);

	public void setPrice(double price);

	public void setStatus(RoomStatus status);

	public void setCustomer(Customer customer);

	public String getRoomNum();

	public RoomType getRoomType();

	public String getDescription();

	public double getPrice();

	public RoomStatus getStatus();

	public Customer getCustomer();

}
