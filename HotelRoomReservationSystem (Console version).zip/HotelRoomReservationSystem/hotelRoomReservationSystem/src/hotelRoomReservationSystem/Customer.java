package hotelRoomReservationSystem;

import java.io.Serializable;
import java.time.LocalDate;

public class Customer implements Serializable {

	private static final long serialVersionUID = 2L;
	private String name;
    private String phNum;
    private int duration;
    private LocalDate reservationDate;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private String comment;
    private double roomFees;

    public Customer(String name, String phNum, int duration, LocalDate reservationDate, LocalDate checkInDate) {
        this.name = name;
        this.phNum = phNum;
        this.duration = duration;
        this.reservationDate = reservationDate;
        this.checkInDate = checkInDate;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the phNum
     */
    public String getPhNum() {
        return phNum;
    }

    /**
     * @param phNum the phNum to set
     */
    public void setPhNum(String phNum) {
        this.phNum = phNum;
    }

    /**
     * @return the duration
     */
    public int getDuration() {
        return duration;
    }

    /**
     * @param duration the duration to set
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * @return the reservationDate
     */
    public LocalDate getReservationDate() {
        return reservationDate;
    }

    /**
     * @return the checkInDate
     */
    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    /**
     * @return the checkOutDate
     */
    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    /**
     * @param reservationDate the reservationDate to set
     */
    public void setReservationDate(LocalDate reservationDate) {
        this.reservationDate = reservationDate;
    }

    /**
     * @param checkInDate the checkInDate to set
     */
    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    /**
     * @param checkOutDate the departureDate to set
     */
    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the roomFees
     */
    public double getRoomFees() {
        return roomFees;
    }

    /**
     * @param roomFees the toatlCost to set
     */
    public void setRoomFees(double roomFees) {
        this.roomFees = roomFees;
    }

}

