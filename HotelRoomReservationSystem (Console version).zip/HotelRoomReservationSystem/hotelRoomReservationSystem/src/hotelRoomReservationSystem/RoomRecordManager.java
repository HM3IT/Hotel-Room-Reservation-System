package hotelRoomReservationSystem;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class RoomRecordManager implements RoomRecordManagerFacade {

	private RoomDataIO roomDataIO;

	RoomRecordManager() {
		roomDataIO = RoomDataIO.getInstance();
	}

	@Override
	public void saveBookingRecord(Room room) {
		// Updating the booking room cache
		roomDataIO.getBookingRoom().add(room);
		addHistory(room);
	}

	@Override
	public void saveCheckInRecord(Room room, boolean haveBooking) {

		roomDataIO.getCheckInRoom().put(room.getRoomNum(), room);
		addHistory(room);
		// removing the customer from booking cache
		if (haveBooking) {
			removeBookingRoom(room);
		}

	}

	@Override
	public void saveCheckOutRecord(Room room) {

		roomDataIO.getCheckOutRoom().add(room);
		roomDataIO.getCheckInRoom().remove(room.getRoomNum());
		addHistory(room);
	}

	private void removeBookingRoom(Room room) {
		Customer baseCustomer = room.getCustomer();
		ArrayList<Room> bookingRoom = roomDataIO.getBookingRoom();

		int length = roomDataIO.getBookingRoom().size();

		for (int i = 0; i < length; i++) {
			Customer customer = bookingRoom.get(i).getCustomer();
			if (customer.getName().equals(baseCustomer.getName())
					&& customer.getPhNum().equals(baseCustomer.getPhNum())) {
				roomDataIO.getBookingRoom().remove(i);
				return;
			}

		}
	}

	@Override
	public boolean saveAllRoomObj() {
		return RoomDataIO.getInstance().saveAllRoomObj();
	}

	// stacking the room history stack
	private void addHistory(Room room) {
		LocalDateTime currentDateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm, dd MMM yyyy");
		String formattedDateTime = currentDateTime.format(formatter);
		RoomRecordStackADT roomHistoryStack = RoomHistoryStack.getInstance();
		roomHistoryStack.push(room, formattedDateTime);
	}

}