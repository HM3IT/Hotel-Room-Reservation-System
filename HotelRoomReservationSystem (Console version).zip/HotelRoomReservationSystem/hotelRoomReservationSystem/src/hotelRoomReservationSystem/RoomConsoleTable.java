package hotelRoomReservationSystem;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

public class RoomConsoleTable {
	void showCheckOutTbl(ArrayList<Room> checkOutRooms) {
		String format = "\n%-15s%-25s%-20s%-20s%-20s%-20s%-20s%-10s%-10s\n\n";
		System.out.printf(format, "Room Number", "Room Type", "Guest", "Phone", "Reservation date", "Check-in date",
				"Check-Out date", "Duration", "Total fees");
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
		for (Room room : checkOutRooms) {
			Customer customer = room.getCustomer();
			String checkInDateStr = customer.getCheckInDate().format(dateFormatter);
			String checkOutDateStr = customer.getCheckOutDate().format(dateFormatter);
			System.out.printf(format, room.getRoomNum(), room.getRoomType().getLabel(), customer.getName(),
					customer.getPhNum(), customer.getReservationDate(), checkInDateStr, checkOutDateStr,
					customer.getDuration(), customer.getRoomFees());
		}

	}

	void showCheckInTbl(HashMap<String, Room> checkInRoomHm) {
		String format = "\n\n%-15s%-25s%-20s%-15s%-20s%-20s%-15s\n";
		System.out.printf(format, "Room Number", "Room Type", "Gest", "Phone", "Reservation date", "Check-in date",
				"Duration");
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
		for (Room room : checkInRoomHm.values()) {

			Customer customer = room.getCustomer();
			String reservationDateStr = customer.getReservationDate().format(dateFormatter);
			String checkInDateStr = customer.getCheckInDate().format(dateFormatter);
			System.out.printf(format, room.getRoomNum(), room.getRoomType().getLabel(), customer.getName(),
					customer.getPhNum(), reservationDateStr, checkInDateStr, customer.getDuration());
		}

	}
}
