package hotelRoomReservationSystem;

public class MainClass {
	public static void main(String[] args) {
		RoomDataRetriever roomDataRetriever;

		roomDataRetriever = RoomDataIO.getInstance();

		RoomRecordManagerFacade roomRecordManager = new RoomRecordManager();

		InputValidator inputValidator = new HotelRoomInputValidator();
		MainMenu mainMenu = new MainMenu(roomDataRetriever, roomRecordManager, inputValidator);
		mainMenu.showWelcomeMesg();
	}
}
