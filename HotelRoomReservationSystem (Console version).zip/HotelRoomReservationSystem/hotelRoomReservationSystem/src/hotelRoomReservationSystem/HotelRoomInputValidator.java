package hotelRoomReservationSystem;

import java.util.regex.Pattern;

public class HotelRoomInputValidator implements InputValidator {
	private Pattern phonePattern;
	private Pattern datePattern;
	private Pattern roomNumberPattern;
	private Pattern namePattern;

	// To improve performance (Compile only once)
	HotelRoomInputValidator() {
		/*
		 * For Myanmar (Local), valid formats for phone numbers: 09-1234567 09-12345678
		 * 09-123456789 09-1234567890
		 */
		phonePattern = Pattern.compile("^09-?\\d{7,9}$");

		/*
		 * Year is restricted to 2023, month is restricted to a range from Mars to
		 * December, day is restricted to a range from 01 to 31, with a leading zero
		 * optional for single-digit days
		 */
		datePattern = Pattern.compile("(0?[1-9]|[1-2][0-9]|3[0-1])-(Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-2023");

		/*
		 * Room.txt file, a file given by the assignment contains only the room numbers
		 * starting with 4 digit to 5 digit at most
		 */
		roomNumberPattern = Pattern.compile("R[1-9]-\\d{4,5}");

		/* only allows alphabet character */
		namePattern = Pattern.compile("^[a-zA-Z\\s]+$");

	}

	@Override
	public boolean isValidDate(String dateString) {

		if (datePattern.matcher(dateString).matches()) {

			// Sample format 17-May-2023 or 7-Jun-2023 or 08-Jun-2023
			String[] date = dateString.split("-");

			int day = Integer.parseInt(date[0]);
			String month = date[1];

			// Checking whether the month & day are valid e.g Feb has only 28 days
			if (month.equals("April") || month.equals("June") || month.equals("Sep") || month.equals("Nov")) {
				if (day <= 30) {
					return true;
				}
			} else {
				if (day <= 31) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public boolean isValidRoomNum(String roomNum) {
		/*
		 * e.g R1-12345
		 */
		roomNumberPattern = Pattern.compile("R[1-9]-\\d{4,5}");
		return roomNumberPattern.matcher(roomNum.trim()).matches();

	}

	@Override
	public boolean isValidPhoneNumber(String phoneNum) {
		phoneNum = phoneNum.replaceAll("\\s", "");

		return phonePattern.matcher(phoneNum).matches();
	}

	@Override
	public boolean isValidName(String name) {

		return namePattern.matcher(name).matches();
	}

	@Override
	public boolean isValidOption(String optionChar, int range) {
		int option;
		try {
			option = Integer.parseInt(optionChar);
		} catch (NumberFormatException e) {
			return false;
		}
		if (option <= 0 || option > range) {
			return false;
		}

		return true;
	}

	@Override
	public boolean isValidDuration(String duration) {

		return duration.matches("\\d+");
	}
}
