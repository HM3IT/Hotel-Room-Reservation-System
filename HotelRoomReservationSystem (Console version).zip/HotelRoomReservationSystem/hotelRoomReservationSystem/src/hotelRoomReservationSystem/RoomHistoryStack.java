package hotelRoomReservationSystem;

import java.util.ArrayList;

public class RoomHistoryStack implements RoomRecordStackADT {

	private static RoomHistoryStack roomHistoryStack;
	private ArrayList<Room> rooms;
	private ArrayList<String> dateTime;
	private int size, top;
	private String categoryFormat;
	private String dataFormat;

	private RoomHistoryStack() {
		rooms = new ArrayList<>();
		dateTime = new ArrayList<>();
		// set the maximum number of rooms to 100
		size = 20;
		top = -1;
		// default format
		dataFormat = "%1$-30s%2$-10s%3$-25s%4$-20s%5$-20s%6$-20s%7$-10s%8$-15s%9$-20s%10$-20s\n";
		categoryFormat = String.format(dataFormat, 
				"DateTime(Hr:min)", 
				"Status", "Room Type",
				"Name",
				"Reservation Date", "Check-in Date",
				"Duration", "Room number", 
				"Check-out Date", "Room Fees");
	}

	protected static RoomRecordStackADT getInstance() {
		if (roomHistoryStack == null) {
			roomHistoryStack = new RoomHistoryStack();
		}
		return roomHistoryStack;
	}

	@Override
	public String getCategoryFormat() {
		return categoryFormat;
	}

	@Override
	public void setCategoryFormat(String categoryFormat) {
		this.categoryFormat = categoryFormat;
	}

	@Override
	public String getDataFormat() {
		return dataFormat;
	}

	@Override
	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}

	@Override
	public void push(Room room, String addedDateTime) {
		// TODO Auto-generated method stub
		if (this.isFull()) {
			System.out.println("Room history will not be recorded as it is full {size:" + size + "}");
		} else {
			rooms.add(++top, room);
			dateTime.add(top, addedDateTime);
		}
	}

	@Override
	public String pop() {
		if (this.isEmpty()) {
			return null;
		}
		Room topMostRoom = rooms.get(top);
		String dateTimeStr = dateTime.get(top);
		top--;

		// remove the popped room from the ArrayList
		// rooms.remove(top+1);
		return showDataFormat(topMostRoom, dateTimeStr);
	}

	@Override
	public String peek() {
		// TODO Auto-generated method stub

		if (this.isEmpty()) {
			System.out.println("Room record is empty is empty");
			return null;
		}
		Room topMostRoom = rooms.get(top);
		String dateTimeStr = dateTime.get(top);

		return showDataFormat(topMostRoom, dateTimeStr);
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return this.size;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return top == (size - 1);
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return top < 0;
	}

	private String showDataFormat(Room topMostRoom, String dateTimeStr) {
		Customer customer = topMostRoom.getCustomer();
		String roomNumber = topMostRoom.getRoomNum() == null ? "-" : topMostRoom.getRoomNum();
		String checkOutDate = customer.getCheckOutDate() == null ? "-" : customer.getCheckOutDate().toString();
		String roomFees = customer.getRoomFees() + "";

		String data = String.format(dataFormat, dateTimeStr, topMostRoom.getStatus().getLabel(),
				topMostRoom.getRoomType().getLabel(), customer.getName(), customer.getReservationDate().toString(),
				customer.getCheckInDate().toString(), customer.getDuration() + "", roomNumber, checkOutDate, roomFees);

		return data;
	}
}
