package hotelRoomReservationSystem;

public enum ReservationSystemOption {

	VIEW_ROOM_INFO("View room information"),
	SEARCH_AVAILABLE_ROOM("Search the available room"),
	ROOM_RESERVATION("Room reservation"), 
	CHECK_IN("Check in"),
	CHECK_OUT("Check out"),
	VIEW_UPDATED_ROOM_INFO("View updated room reservation information"),
    EXIT("Exit");

	private final String label;

	ReservationSystemOption(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static ReservationSystemOption getSystemOptionEnum(int ordinal) {

		ReservationSystemOption[] systemOptions = ReservationSystemOption.values();
		if (ordinal < 0 || ordinal >= systemOptions.length) {
			throw new IllegalArgumentException("Invalid ordinal: " + ordinal);
		}
		return systemOptions[ordinal];
	}
}
