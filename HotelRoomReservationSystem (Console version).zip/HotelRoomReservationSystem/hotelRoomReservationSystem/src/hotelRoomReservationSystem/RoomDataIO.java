package hotelRoomReservationSystem;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class RoomDataIO implements RoomDataRetriever {

	private static RoomDataIO database;
	private ArrayList<Room> bookingRooms;
	private HashMap<String, Room> checkInRooms;
	private ArrayList<Room> checkOutRooms;
	private final String ROOM_FILE_PATH = "src/Data/Room.txt";
	private final String RESERVATION_RECORD_FILE_PATH = "src/Data/ReservationRecord.ser";
	private final String CHECKIN_RECORD_FILE_PATH = "src/Data/CheckInRecord.ser";
	private final String CHECKOUT_RECORD_FILE_PATH = "src/Data/CheckOutRecord.ser";

	private RoomDataIO() {
		checkInRooms = new HashMap<>();
		bookingRooms = new ArrayList<>();
		checkOutRooms = new ArrayList<>();
		try {
			loadRoomObj();
		} catch (IOException e) {
			System.out.println(e);

			e.printStackTrace();
			System.exit(0);
		}
	}

	protected static RoomDataIO getInstance() {
		if (database == null) {
			database = new RoomDataIO();
		}
		return database;
	}

	@Override
	public HashMap<String, Room> getCheckInRoom() {
		return checkInRooms;
	}

	@Override
	public ArrayList<Room> getBookingRoom() {
		return bookingRooms;
	}

	@Override
	public ArrayList<Room> getCheckOutRoom() {
		return checkOutRooms;

	}

	@Override
	public String getAvailableRoomNum(RoomType roomType) {
		// TODO Auto-generated method stub
		String[] roomNums = getRoomNumsBasedType(roomType);
		for (String roomNum : roomNums) {
			if (getCheckInRoom().get(roomNum) == null) {
				return roomNum;
			}
		}

		return null;
	}

	@Override
	public ArrayList<String> getAvailableRoomNums(RoomType roomType) {

		String[] roomNums = getRoomNumsBasedType(roomType);
		ArrayList<String> availableRoomNums = new ArrayList<>();
		for (String roomNum : roomNums) {
			if (checkInRooms.get(roomNum) == null) {
				availableRoomNums.add(roomNum);
			}
		}
		return availableRoomNums;
	}

	@Override
	public Room getRoomBaseType(RoomType basedRoomType) {
		try (BufferedReader br = new BufferedReader(new FileReader(ROOM_FILE_PATH))) {
			String str = br.readLine();

			while (str != null) {
				String[] values = str.split("#");
				RoomType roomType = RoomType.getRoomTypeEnum(values[0]);
				if (roomType == basedRoomType) {
					String description = values[1];
					double price = Double.parseDouble(values[2]);
					Room room = new BasicRoom(roomType);
					room.setDescription(description);
					room.setPrice(price);
					return room;
				}
				str = br.readLine();
			}
		} catch (IOException e) {
			System.err.println(ROOM_FILE_PATH + " not found {file reader errors occur}");
		}
		return null;
	}

	/**
	 * @return arrayList that contains one room for each type without including room
	 *         number data
	 *
	 */

	@Override
	public ArrayList<Room> getRoomForEachType() {

		ArrayList<Room> roomTypeAryList = new ArrayList<>();

		try (BufferedReader br = new BufferedReader(new FileReader(ROOM_FILE_PATH))) {
			String str = br.readLine();

			while (str != null) {
				String[] values = str.split("#");
				RoomType roomType = RoomType.getRoomTypeEnum(values[0]);
				String description = values[1];
				double price = Double.parseDouble(values[2]);

				Room room = new BasicRoom(roomType, description, price);
				room.setDescription(description);
				room.setPrice(price);
				roomTypeAryList.add(room);
				str = br.readLine();
			}
			return roomTypeAryList;
		} catch (IOException e) {
			System.err.println(ROOM_FILE_PATH + " not found {file reader errors occur}");
		}
		return null;
	}

	boolean saveAllRoomObj() {
		return (writeRoomRecordObj(RESERVATION_RECORD_FILE_PATH, bookingRooms)
				&& writeRoomRecordObj(CHECKIN_RECORD_FILE_PATH, checkInRooms)
				&& writeRoomRecordObj(CHECKOUT_RECORD_FILE_PATH, checkOutRooms));
	}

	private void loadRoomObj() throws FileNotFoundException, IOException {
		bookingRooms = readRoomRecordObj(RESERVATION_RECORD_FILE_PATH);
		checkInRooms = readRoomRecordObj(CHECKIN_RECORD_FILE_PATH);
		checkOutRooms = readRoomRecordObj(CHECKOUT_RECORD_FILE_PATH);
	}

	/**
	 * 
	 * @return array that contains Room numbers that has the same room type
	 */
	@Override
	public String[] getRoomNumsBasedType(RoomType roomType) {

		String roomTypeStr = roomType.getLabel();

		try (BufferedReader br = new BufferedReader(new FileReader(ROOM_FILE_PATH))) {
			String str = br.readLine();

			while (str != null) {

				String[] values = str.split("#");
				if (values[0].equalsIgnoreCase(roomTypeStr)) {
					return values[3].split(",");
				}
				str = br.readLine();
			}
		} catch (IOException e) {
			System.err.println(ROOM_FILE_PATH + " file reader occurs");
		}
		return null;
	}

	<T> boolean writeRoomRecordObj(String filePath, T data) {
		try (ObjectOutputStream objectOut = new ObjectOutputStream(new FileOutputStream(filePath))) {
			objectOut.writeObject(data);
			return true;
		} catch (IOException e) {
			System.out.println(filePath + " failed to write");
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	<T> T readRoomRecordObj(String filePath) {
		try (ObjectInputStream objectIn = new ObjectInputStream(new FileInputStream(filePath))) {
			T data = (T) objectIn.readObject();
			return data;
		} catch (IOException e) {
			System.out.println(filePath + " failed to read");
		} catch (ClassNotFoundException e) {
			System.out.println(filePath + " not found");
		}
		return null;
	}

}
