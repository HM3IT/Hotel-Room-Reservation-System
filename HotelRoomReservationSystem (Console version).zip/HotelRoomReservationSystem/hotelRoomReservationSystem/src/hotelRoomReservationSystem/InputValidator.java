package hotelRoomReservationSystem;

public interface InputValidator {
	
	boolean isValidDate(String dateString);

	boolean isValidRoomNum(String roomNum);

	boolean isValidPhoneNumber(String phoneNum);

	boolean isValidName(String name);

	boolean isValidOption(String optionChar, int range);
	
	boolean isValidDuration(String duration);
}
