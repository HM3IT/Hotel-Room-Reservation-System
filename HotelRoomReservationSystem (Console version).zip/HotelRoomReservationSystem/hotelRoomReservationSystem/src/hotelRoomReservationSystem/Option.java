package hotelRoomReservationSystem;

public class Option {

	protected void showReservationSystemOption() {
		System.out.println("\n*****************************************");
		ReservationSystemOption[] options = ReservationSystemOption.values();
		for (ReservationSystemOption option : options) {
			System.out.println((option.ordinal() + 1) + ". " + option.getLabel());
		}
	}

	protected void showRoomTypeOption() {
		System.out.println("\n*****************************************");
		System.out.println("Hotel Room Reservation System (Room Types):");
		RoomType[] roomTypes = RoomType.values();
		for (RoomType roomType : roomTypes) {
			System.out.println((roomType.ordinal() + 1) + ". " + roomType.getLabel());
		}
	}
	
	protected void showRoomStatusOption() {
		System.out.println("\n*****************************************");
		System.out.println("Hotel Room Reservation System (Updated room reservation information):");
		RoomType[] roomTypes = RoomType.values();
		for (RoomType roomType : roomTypes) {
			System.out.println((roomType.ordinal() + 1) + ". " + roomType.getLabel());
		}
	}
}
