package hotelRoomReservationSystem;

import java.io.Serializable;

class BasicRoom implements Room, Serializable {
	private static final long serialVersionUID = 1L;
	private String roomNum;
	private RoomType roomType;
	private String description;
	private double price;
	private RoomStatus status;
	private Customer customer;

	public BasicRoom(RoomType roomType) {
		this.roomType = roomType;
	}

	public BasicRoom(RoomType roomType, String description, double price) {
		this.roomType = roomType;
		this.description = description;
		this.price = price;
	}

	public BasicRoom(RoomType roomType, String description, double price, RoomStatus status, String roomNum) {
		this(roomType, description, price);
		this.status = status;
		this.roomNum = roomNum;
	}

	@Override
	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}

	@Override
	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	@Override
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public void setStatus(RoomStatus status) {
		this.status = status;
	}

	@Override
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String getRoomNum() {
		return this.roomNum;
	}

	@Override
	public RoomType getRoomType() {
		return this.roomType;
	}

	@Override
	public String getDescription() {
		return this.description;
	}

	@Override
	public double getPrice() {
		return this.price;
	}

	@Override
	public RoomStatus getStatus() {
		return this.status;
	}

	@Override
	public Customer getCustomer() {
		return customer;
	}
	
}
