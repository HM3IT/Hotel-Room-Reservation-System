package hotelRoomReservationSystem;

public class OptionToEnumRetriever {

	public RoomType getRoomTypeFromOption(String optionStr) {

		int ordinal = Integer.parseInt(optionStr) - 1;
		RoomType selectedRoomType = RoomType.getRoomTypeEnum(ordinal);
		System.out.println("\nSelected room type *{" + selectedRoomType.getLabel() + "}*");
		return selectedRoomType;
	}

	public ReservationSystemOption getSystemOptionFromOption(String optionStr) {
		
		int ordinal = Integer.parseInt(optionStr) - 1;
		ReservationSystemOption selectedRoomType = ReservationSystemOption.getSystemOptionEnum(ordinal);
		return selectedRoomType;
	}
}
