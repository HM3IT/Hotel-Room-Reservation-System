package hotelRoomReservationSystem;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class MainMenu implements ReservationSystemADT {

	private Scanner scan;
	private RoomDataRetriever roomDataRetriever;
	private RoomRecordManagerFacade roomRecordManager;
	private InputValidator inputValidator;
	private OptionToEnumRetriever enumRetriever;
	private Option option;
	private RoomConsoleTable consoleTable;

	MainMenu(RoomDataRetriever roomDataRetriever, RoomRecordManagerFacade roomRecordManager,
			InputValidator inputValidator) {

		scan = new Scanner(System.in);
		this.roomDataRetriever = roomDataRetriever;
		this.roomRecordManager = roomRecordManager;
		this.inputValidator = inputValidator;
		this.enumRetriever = new OptionToEnumRetriever();
		this.option = new Option();
		consoleTable = new RoomConsoleTable();
	}

	@Override
	public void showWelcomeMesg() {

		System.out.println();
		System.out.println("Welcome To Hotel Room Reservation System");
		chooseOption();
	}

	@Override
	public void showRoomInfo() {

		System.out.println("");
		System.out.println("++++++++++++++++++++ Room Information +++++++++++++++++++++++++");
		System.out.println("+++++++++++++++++++++   |||    +++++++++++++++++++++++++");
		System.out.printf("%1$-30s%2$-20s%3$-45s\n", "Room type", "Price", "Description");
		ArrayList<Room> rooms = roomDataRetriever.getRoomForEachType();
		for (Room room : rooms) {
			String[] descriptions = room.getDescription().split(",");
			System.out.printf("%1$-30s%2$-20.1f%3$-45s\n", room.getRoomType().getLabel(), room.getPrice(),
					descriptions[0]);
		}
		System.out.println("\n\n");
	}

	@Override
	public void searchAvailableRoom() {

		System.out.println("Searching for the available room");
		System.out.println("\n*****************************************");
		option.showRoomTypeOption();
		char status;

		do {
			String optionChar;
			while (true) {
				System.out.print("\nChoose Option (e.g. 1, 2, 3) :");
				optionChar = scan.nextLine();
				if (inputValidator.isValidOption(optionChar, RoomType.values().length)) {
					break;
				}
				System.out.println("\nInvalid format! Please enter again in number \n");
			}

			// retrieving the user selected's room type
			RoomType roomType = enumRetriever.getRoomTypeFromOption(optionChar);

			// Available room data retrieving process
			ArrayList<String> availableRoomNums = roomDataRetriever.getAvailableRoomNums(roomType);

			int count = availableRoomNums.size();
			if (count <= 0) {
				System.out.println("No, there is no available room for " + roomType);
			} else {
				System.out.println("\nYes, there are " + count + " available rooms for " + roomType.getLabel());
				pause(1);
				System.out.println("\nThe available room numbers for " + roomType.getLabel() + " are :\n\n");
				int column = 1;
				StringBuilder roomNumsBuild = new StringBuilder();
				for (String roomNum : availableRoomNums) {
					roomNumsBuild.append(roomNum);
					roomNumsBuild.append("|| ");
					if (column % 4 == 0) {
						roomNumsBuild.append("\n");
					}
					column++;
				}
				System.out.println(roomNumsBuild);

			}
			System.out.print("Do you want to search another room type ? (Y/N) :");
			status = scan.nextLine().charAt(0);
		} while (status == 'y' || status == 'Y');

	}

	@Override
	public Room makeReservationRoom() {

		option.showRoomTypeOption();
		String optionStr;
		while (true) {
			System.out.print("\nChoose room type :");
			optionStr = scan.nextLine();
			if (inputValidator.isValidOption(optionStr, RoomType.values().length)) {
				break;
			}
			System.out.println("The option is invalid");
		}

		RoomType roomType = enumRetriever.getRoomTypeFromOption(optionStr);

		System.out.print("\nPlease enter customer name :");
		String customerName = scan.nextLine();
		while (!inputValidator.isValidName(customerName)) {
			System.out.print(
					"Invalid naming format! (Name cannot contain digit number and special character)\nPlease enter customer name :");
			customerName = scan.nextLine();
		}

		String checkInDateStr;
		while (true) {
			System.out.print("\nPlease enter check-in date (e.g 10-Apr-2023) :");
			checkInDateStr = scan.nextLine();

			if (inputValidator.isValidDate(checkInDateStr)) {
				break;
			}
			System.out.println("Invalid check-in date");
		}

		// A pattern that allows for both leading zeros and non-leading zeros in the
		// month and day fields.
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
		LocalDate checkInDate = LocalDate.parse(checkInDateStr, dateFormatter);
		LocalDate reservationDate = LocalDate.now();

		int duration;
		while (true) {
			System.out.print("\nPlease enter duration in digit :");
			String durationStr = scan.nextLine();

			if (inputValidator.isValidDuration(durationStr)) {
				duration = Integer.parseInt(durationStr);
				if (duration > 0 && duration <= 14) {
					break;
				}
				System.out.println("Room cannot reserved more than two weeks");
			}
			System.out.print("\n Invalid duration format!");
		}

		System.out.print("\nPlease enter customer phone number :");
		String phone = scan.nextLine();
		while (!inputValidator.isValidPhoneNumber(phone)) {
			System.out.print("\nInvalid phone number! Please enter customer phone number :");
			phone = scan.nextLine();
		}

		// certain to get the Room object back since the @param roomType has been
		// validated
		Customer customer = new Customer(customerName, phone, duration, reservationDate, checkInDate);
		Room room = roomDataRetriever.getRoomBaseType(roomType);
		room.setCustomer(customer);
		room.setStatus(RoomStatus.BOOKING);
		System.out.println("\nReservation is successfully made\n");
		return room;
	}

	@Override
	public void checkInRoom() {

		System.out.print("Is a booking customer? (Y/N) :");
		char hasBooking = scan.nextLine().charAt(0);

		boolean isBookingCustomer;

		Room room;
		if (hasBooking == 'Y' || hasBooking == 'y') {
			room = getRoomFromBooking();
			if (room == null) {
				return;
			}
			isBookingCustomer = true;

		} else {
			room = makeReservationRoom();
			isBookingCustomer = false;
		}
		while (true) {

			String roomNum = roomDataRetriever.getAvailableRoomNum(room.getRoomType());
			// Room is available
			if (roomNum != null) {
				System.out.println("Your room number is :" + roomNum);
				room.setRoomNum(roomNum);
				room.setStatus(RoomStatus.CHECK_IN);
				roomRecordManager.saveCheckInRecord(room, isBookingCustomer);

				HashMap<String, Room> recentCheckInRoom = new HashMap<>(1);
				recentCheckInRoom.put(roomNum, room);
				consoleTable.showCheckInTbl(recentCheckInRoom);

				System.out.println("\nCheck-in is successfully made\n");
				return;
			}
			// No available room for the user selected room type
			System.out.println("There is no available room for " + room.getRoomType());
			System.out.print("Want to choose other room types(Y/N):");
			char choice = scan.nextLine().charAt(0);

			if (choice == 'Y' || choice == 'y') {
				option.showRoomTypeOption();
				while (true) {

					String optionStr = scan.nextLine();
					if (inputValidator.isValidOption(optionStr, RoomType.values().length)) {
						RoomType roomType = enumRetriever.getRoomTypeFromOption(optionStr);
						room.setRoomType(roomType);
						break;
					}
					System.out.print("Plase choose only valid option :");
				}

			} else {
				break;
			}
		}

	}

	@Override
	public void checkOutRoom() {

		Room room = getRoomFromCheckIn();
		if (room == null) {
			return;
		}
		// A pattern that allows for both leading zeros and non-leading zeros in the
		// month and day fields.
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
		LocalDate checkOutDate;
		String checkOutDateStr;
		while (true) {
			System.out.print("\nPlease enter check-out date (e.g 10-Apr-2023) :");
			checkOutDateStr = scan.nextLine();

			if (inputValidator.isValidDate(checkOutDateStr)) {
				checkOutDate = LocalDate.parse(checkOutDateStr, dateFormatter);
				LocalDate checkInDate = room.getCustomer().getCheckInDate();

				if (checkOutDate.isAfter(checkInDate) || checkOutDate.isEqual(checkInDate)) {
					break;
				}
				System.out.println("The check-out can't be before the check-in date. ");
			}
			System.out.println("Invalid check-in date");
		}

		int actualDuration = (int) ChronoUnit.DAYS.between(room.getCustomer().getCheckInDate(), checkOutDate);
		if (actualDuration <= 0) {
			actualDuration = 1;
		}
		double totalFees = room.getPrice() * actualDuration;
		room.getCustomer().setCheckOutDate(checkOutDate);
		room.getCustomer().setRoomFees(totalFees);
		room.getCustomer().setDuration(actualDuration);
		room.setStatus(RoomStatus.CHECK_OUT);

		ArrayList<Room> recentCheckOutRoom = new ArrayList<>(1);
		recentCheckOutRoom.add(room);
		consoleTable.showCheckOutTbl(recentCheckOutRoom);
		roomRecordManager.saveCheckOutRecord(room);
		System.out.println("\nCheck-out successfully");
	}

	@Override
	public void showUpdatedRoomInfo() {

		RoomRecordStackADT roomHistoryStack = RoomHistoryStack.getInstance();
		if (roomHistoryStack.isEmpty()) {
			System.out.println("You have not update any room record yet");
			return;
		}
		System.out.println(roomHistoryStack.getCategoryFormat());
		while (!roomHistoryStack.isEmpty()) {
			System.out.println(roomHistoryStack.pop());
		}
	}

	@Override
	public void exit() {

		scan.close();
		roomRecordManager.saveAllRoomObj();
		System.out.println("\n***** Thank you ******");
		System.out.println("**      ________      **");
		System.exit(0);
	}

	private void chooseOption() {
		String optionStr;

		while (true) {
			option.showReservationSystemOption();
			System.out.print("\nChoose Option :");
			optionStr = scan.nextLine();
			if (inputValidator.isValidOption(optionStr, ReservationSystemOption.values().length)) {
				break;
			}
			System.out.println("\nInvalid option: Please enter agian in number :");
		}

		ReservationSystemOption selectedOption = enumRetriever.getSystemOptionFromOption(optionStr);

		direct(selectedOption);
	}

	private void direct(ReservationSystemOption selectedOption) {
		switch (selectedOption) {
		case VIEW_ROOM_INFO: {
			showRoomInfo();
			pause(1);
			if (isContinue()) {
				chooseOption();
				break;
			}
			exit();
			break;
		}
		case SEARCH_AVAILABLE_ROOM: {
			searchAvailableRoom();
			pause(.5);
			chooseOption();
			break;
		}
		case ROOM_RESERVATION: {
			Room room = makeReservationRoom();
			if (room != null) {
				roomRecordManager.saveBookingRecord(room);
			}
			pause(1);
			chooseOption();
			break;
		}
		case CHECK_IN: {
			checkInRoom();
			pause(1.5);
			chooseOption();
			break;
		}
		case CHECK_OUT: {
			checkOutRoom();
			pause(1);
			chooseOption();
			break;
		}
		case VIEW_UPDATED_ROOM_INFO: {
			showUpdatedRoomInfo();
			pause(1);
			if (isContinue()) {
				chooseOption();
				break;
			}
			exit();
			break;
		}
		case EXIT:
			exit();
			break;
		default: {
			throw new IllegalArgumentException("The option has not implemented");
		}
		}
	}

	private void pause(double second) {
		// To smooth the console
		try {
			int milliseconds = (int) (second * 1000);
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private boolean isContinue() {

		System.out.printf("Do you want to continue (Y/N) :");
		char status = scan.nextLine().charAt(0);

		if (status == 'Y' || status == 'y') {
			return true;
		}
		return false;
	}

	private Room getRoomFromBooking() {

		ArrayList<Room> bookingRooms = roomDataRetriever.getBookingRoom();
		int length = bookingRooms.size();
		if (length <= 0) {
			System.out.println("\nThere is no booking room");
			return null;
		}
		String format = "%-5s%-25s%-20s%-25s%-15s\n";
		System.out.printf(format, "No.", "Name", "Phone", "Room Type", "Duration");

		for (int i = 0; i < length; i++) {
			Room bookingRoom = bookingRooms.get(i);
			Customer customer = bookingRoom.getCustomer();
			System.out.printf(format, i + 1, customer.getName(), customer.getPhNum(),
					bookingRoom.getRoomType().getLabel(), customer.getDuration());
		}

		while (true) {
			System.out.print("\n\nPlease select the number [To select the booking] :");
			String indexString = scan.nextLine();

			if (inputValidator.isValidOption(indexString, length)) {
				// minus one since the index start with zero
				int index = Integer.parseInt(indexString) - 1;

				return bookingRooms.get(index);
			} else {
				System.out.println("The selected option is not valid");
				if (!isContinue()) {
					return null;
				}
			}
		}

	}

	private Room getRoomFromCheckIn() {

		HashMap<String, Room> checkInRoomHm = roomDataRetriever.getCheckInRoom();

		int length = checkInRoomHm.size();
		if (length <= 0) {
			System.out.println("There is no check-in customers at the moment");
			return null;
		}
		consoleTable.showCheckInTbl(checkInRoomHm);
		String roomNum;
		while (true) {
			System.out.print("\nEnter room number :");
			roomNum = scan.nextLine();
			roomNum.trim();
			if (inputValidator.isValidRoomNum(roomNum)) {
				break;
			}
			System.out.println("\nInvalid room number! Please try again (e.g. R1-1000)\n");
		}

		// Directly accessing the room object that is about to be checked out
		Room room = checkInRoomHm.get(roomNum);
		if (room == null) {
			System.out.println("There is no check-in customer in that Room No." + roomNum);
			return null;
		}

		return room;
	}

}
