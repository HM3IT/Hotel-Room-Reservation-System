package hotelRoomReservationSystem;

public interface ReservationSystemADT {
	
	public void showWelcomeMesg();

	public void showRoomInfo();

	public void searchAvailableRoom();

	public Room makeReservationRoom();

	public void checkInRoom();

	public void checkOutRoom();

	public void showUpdatedRoomInfo();

	public void exit();
}
