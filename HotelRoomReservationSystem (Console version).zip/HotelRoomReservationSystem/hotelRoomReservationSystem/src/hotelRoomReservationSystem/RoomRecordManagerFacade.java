package hotelRoomReservationSystem;

public interface RoomRecordManagerFacade {

	public void saveBookingRecord(Room room);

	public void saveCheckInRecord(Room room, boolean isBookingCustomer);

	public void saveCheckOutRecord(Room room);
	
	public boolean saveAllRoomObj();
		
}
