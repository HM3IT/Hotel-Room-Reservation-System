package hotelRoomReservationSystem;

public interface RoomRecordStackADT {
	void push(Room room, String addedDateTime);

	String pop();

	String peek();

	int size();

	boolean isFull();

	boolean isEmpty();
	
	void setDataFormat(String format);
	
	String getDataFormat();

	String getCategoryFormat();

	void setCategoryFormat(String categoryFormat);
}
