package hotelRoomReservationSystem;

import java.util.ArrayList;
import java.util.HashMap;

public interface RoomDataRetriever {

	public ArrayList<Room> getBookingRoom();

	public HashMap<String, Room> getCheckInRoom();

	public ArrayList<Room> getCheckOutRoom();

	public Room getRoomBaseType(RoomType basedRoomType);

	public ArrayList<Room> getRoomForEachType();

	public String getAvailableRoomNum(RoomType roomType);

	public ArrayList<String> getAvailableRoomNums(RoomType roomType);

	public String[] getRoomNumsBasedType(RoomType roomType);
}
